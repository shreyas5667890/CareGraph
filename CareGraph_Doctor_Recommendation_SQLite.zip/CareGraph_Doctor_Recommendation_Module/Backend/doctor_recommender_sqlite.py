"""SQLite-backed doctor lookup for CareGraph demo data."""
from __future__ import annotations
import os, re, sqlite3
from pathlib import Path
from typing import Any

BACKEND_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = BACKEND_DIR.parent
DEFAULT_DB = PROJECT_ROOT / "Data" / "caregraph_doctors.db"

def _key(value: Any) -> str:
    value = str(value or "").strip().lower()
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]+", " ", value)).strip()

ALIASES = {
    "internal medcine": "internal medicine",
    "internal medicine": "internal medicine",
    "dermatologists": "dermatologist",
    "rheumatologists": "rheumatologist",
    "gynaecologist": "gynecologist",
    "ent specialist": "otolaryngologist",
}
DISPLAY = {
    "allergist":"Allergist", "cardiologist":"Cardiologist",
    "dermatologist":"Dermatologist", "endocrinologist":"Endocrinologist",
    "gastroenterologist":"Gastroenterologist", "gynecologist":"Gynecologist",
    "hepatologist":"Hepatologist", "internal medicine":"Internal Medicine",
    "neurologist":"Neurologist", "osteopathic":"Osteopathic",
    "otolaryngologist":"Otolaryngologist", "pediatrician":"Pediatrician",
    "phlebologist":"Phlebologist", "pulmonologist":"Pulmonologist",
    "rheumatologist":"Rheumatologist",
}
def canonical_specialty(value):
    k = ALIASES.get(_key(value), _key(value))
    return DISPLAY.get(k, str(value or "").strip())

class DoctorRecommender:
    def __init__(self, db_path=None):
        self.db_path = Path(db_path or os.getenv("CAREGRAPH_DOCTOR_DB", str(DEFAULT_DB)))
        if not self.db_path.is_absolute():
            self.db_path = (PROJECT_ROOT / self.db_path).resolve()
        self.load_error = None
        if not self.db_path.exists():
            self.load_error = f"Doctor database not found: {self.db_path}"

    def _connect(self):
        con = sqlite3.connect(str(self.db_path))
        con.row_factory = sqlite3.Row
        return con

    def search(self, specialty: str, city: str | None = None, limit: int = 10,
               sort_by: str = "recommended") -> dict:
        if self.load_error:
            return {"success": False, "error": "Doctor database is unavailable.", "details": self.load_error, "doctors": []}
        if not specialty or not str(specialty).strip():
            return {"success": False, "error": "The 'specialty' parameter is required.", "doctors": []}
        requested = canonical_specialty(specialty)
        if city:
            city_key = _key(city)
            if city_key not in {"mumbai", "thane"}:
                return {"success": False, "error": "City must be Mumbai or Thane.", "doctors": []}
            city = "Mumbai" if city_key == "mumbai" else "Thane"
        try:
            limit = max(1, min(int(limit), 50))
        except (TypeError, ValueError):
            limit = 10
        order = {
            "rating": '"Rating_Out_of_5" DESC, "Experience_Years" DESC',
            "fees": '"Consultation_Fee_INR" ASC, "Rating_Out_of_5" DESC',
            "experience": '"Experience_Years" DESC, "Rating_Out_of_5" DESC',
            "recommended": '"Rating_Out_of_5" DESC, "Experience_Years" DESC',
        }.get(sort_by, '"Rating_Out_of_5" DESC, "Experience_Years" DESC')
        sql = 'SELECT * FROM doctors WHERE lower(trim(Specialization)) = lower(trim(?))'
        params = [requested]
        if city:
            sql += ' AND lower(trim(City)) = lower(trim(?) )'
            params.append(city)
        sql += f' ORDER BY {order} LIMIT ?'
        params.append(limit)
        try:
            with self._connect() as con:
                rows = con.execute(sql, params).fetchall()
        except sqlite3.Error as exc:
            return {"success": False, "error": "Doctor database query failed.", "details": str(exc), "doctors": []}
        def val(row, key, digits=None):
            x = row[key]
            if x is None: return None
            if isinstance(x, float) and pd_is_nan(x): return None
            if digits is not None: return round(float(x), digits)
            if isinstance(x, float) and x.is_integer(): return int(x)
            return x
        doctors=[]
        for row in rows:
            doctors.append({
                "doctor_id": str(row["Doctor_ID"]),
                "name": str(row["Doctor_Name"]),
                "specialization": canonical_specialty(row["Specialization"]),
                "age": val(row,"Age"),
                "experience_years": val(row,"Experience_Years"),
                "description": str(row["Description"]),
                "address": str(row["Address"]),
                "city": str(row["City"]),
                "state": str(row["State"]),
                "latitude": val(row,"Latitude",6),
                "longitude": val(row,"Longitude",6),
                "consultation_fee_inr": val(row,"Consultation_Fee_INR"),
                "rating_out_of_5": val(row,"Rating_Out_of_5",1),
                "data_status": str(row["Data_Status"]),
            })
        return {
            "success": True, "requested_specialty": requested,
            "city_filter": city, "count": len(doctors), "doctors": doctors,
            "notice": "Demo directory only: doctor profiles are synthetic and coordinates are approximate. Verify real providers before patient use."
        }

def pd_is_nan(x):
    return x != x

doctor_recommender = DoctorRecommender()
