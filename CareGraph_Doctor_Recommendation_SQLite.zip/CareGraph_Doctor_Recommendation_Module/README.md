# CareGraph Doctor Recommendation Module (Demo)

This module adds specialty-based doctor directory search to the existing CareGraph Flask backend. It uses the existing symptom analysis and disease-to-specialty mapping; it does not create a second disease model.

## Project layout

Copy the `Backend` and `Data` folders into your existing CareGraph project, merging with the existing folders:

```text
CareGraph/
├── Backend/
│   ├── app.py                         # updated API with doctor routes
│   ├── doctor_recommender.py          # specialty-based directory lookup
│   └── requirements.txt
├── Data/
│   └── CareGraph_Doctor_Directory_Mumbai_Thane_Synthetic.xlsx
├── Recommendation/
│   └── caregraph_recommendation_artifacts/  # keep your existing model artifacts
└── SymptomExtraction/                       # keep your existing symptom pipeline
```

**Back up your current `Backend/app.py` before replacing it.** Keep the existing `Recommendation` and `SymptomExtraction` folders in place. The Excel directory is expected under `CareGraph/Data/`; alternatively set `CAREGRAPH_DOCTOR_DIRECTORY` to its full path.

## Install and run (Windows PowerShell)

```powershell
cd C:\Users\Shreyas\Desktop\CareGraph
.\SymptomExtraction\.venv\Scripts\Activate.ps1
python -m pip install -r Backend\requirements.txt
python Backend\app.py
```

## API usage

### 1. Doctor search by specialty

```http
GET http://127.0.0.1:5000/api/doctors?specialty=Cardiologist
GET http://127.0.0.1:5000/api/doctors?specialty=Neurologist&city=Thane&limit=5
GET http://127.0.0.1:5000/api/doctors?specialty=Dermatologist&sort=fees
```

Supported query parameters:
- `specialty` (required)
- `city` (optional: `Mumbai` or `Thane`)
- `limit` (optional: 1–50)
- `sort` (optional: `recommended`, `rating`, `fees`, `experience`)

### 2. Analyze symptoms and include doctors

PowerShell example:

```powershell
$body = @{
    text = "I have a headache and nausea."
    top_k = 3
    city = "Thane"
    doctors_per_specialty = 5
} | ConvertTo-Json

Invoke-RestMethod `
    -Uri "http://127.0.0.1:5000/api/analyze" `
    -Method Post `
    -ContentType "application/json" `
    -Body $body | ConvertTo-Json -Depth 15
```

The response's `recommendation.doctor_recommendations` contains one group per distinct specialty found among the model's disease candidates. Each group includes the associated candidate disease, specialty, and matching directory doctors. The optional `city` filters results to Mumbai or Thane; omit it to show both.

### 3. Existing normalized symptom endpoint

`POST /api/recommend` also attaches doctor results. Example JSON:

```json
{
  "symptoms": ["headache", "nausea"],
  "top_k": 3,
  "city": "Mumbai",
  "doctors_per_specialty": 5
}
```

## Safety and data-quality notes

- The doctor directory contains **fictional synthetic demo records**. Names, profiles, addresses, fees, ratings, and approximate locality coordinates are not verified real providers. Do not use them to direct real patients to clinics.
- `Rating_Out_of_5` is synthetic and must not be presented as a real review score.
- The existing disease-to-specialty mapping is flagged for medical review. Model candidates and scores are not diagnoses or validated referral probabilities.
- Before patient-facing release, replace the workbook with verified providers, accurate clinic addresses/coordinates, consented/authorized information, and a reviewed specialty taxonomy. Add availability/booking only if connected to a real provider source.
