# CareGraph Doctor Recommendation — SQLite edition

This package moves doctor-directory lookup from Excel/Pandas to SQLite queries.

## Contents
- `Data/caregraph_doctors.db`: SQLite database populated from the synthetic Mumbai–Thane directory.
- `Backend/doctor_recommender_sqlite.py`: database-backed search module.
- `Backend/import_doctors_to_sqlite.py`: rebuild the database after updating the Excel source.
- `Backend/app.py`: the prior Flask API starter. Update its doctor recommender import from `doctor_recommender` to `doctor_recommender_sqlite` (see below) if you want this module to replace the Excel lookup.

## Use the SQLite recommender
From the project root:
```powershell
python -c "from Backend.doctor_recommender_sqlite import doctor_recommender; print(doctor_recommender.search('Neurologist', city='Thane', limit=5))"
```
If your `Backend` directory is run as the current working directory, use:
```powershell
python -c "from doctor_recommender_sqlite import doctor_recommender; print(doctor_recommender.search('Neurologist', city='Thane', limit=5))"
```

## Connect it to Flask
In `Backend/app.py`, replace:
```python
from doctor_recommender import doctor_recommender
```
with:
```python
from doctor_recommender_sqlite import doctor_recommender
```
Keep the existing `/api/doctors` route and calls to `doctor_recommender.search(...)` unchanged. Back up your current app.py before editing. If your import is package-qualified, use `from Backend.doctor_recommender_sqlite import doctor_recommender` instead.

## Update data later
Edit `Data/CareGraph_Doctor_Directory_Mumbai_Thane_Synthetic.xlsx`, then run:
```powershell
python Backend/import_doctors_to_sqlite.py
```
The SQLite database is rebuilt from the `Doctors` worksheet.

## Example API calls
```http
GET /api/doctors?specialty=Neurologist
GET /api/doctors?specialty=Cardiologist&city=Mumbai&sort=fees&limit=5
GET /api/doctors?specialty=Gynecologist&city=Thane&sort=rating
```

## Safety and data provenance
The included doctors are fictional demo records; addresses are illustrative and coordinates approximate. Do not use them as real referrals. Before real patient-facing use, replace them with verified providers and obtain appropriate consent for any personal/clinical data handled by the application.
